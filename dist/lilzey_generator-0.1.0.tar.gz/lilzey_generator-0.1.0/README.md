
This simple tool helps you generate random passwords.

## Installation

1. Clone the repository:

    ```bash
    git clone https://github.com/hw010101/lilzey_generator.git
    ```

2. Navigate to the project directory:

    ```bash
    cd lilzey_generator
    ```

3. Install the required dependencies:

    ```bash
    pip install -r requirements.txt
    ```

## Usage

You can run the program with the following command:

```bash
python3 generator.py

